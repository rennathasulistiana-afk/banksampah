<?php
$koneksi = mysqli_connect("localhost", "root", "", "banksampah_renata");
?>
